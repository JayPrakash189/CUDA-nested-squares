"""
nested_squares.py
=================
Hard (CO4) | DS11 | Roll: 25201328
Nested Square Pattern — CUDA GPU vs Sequential CPU

Run on Google Colab: paste into a single cell after enabling T4 GPU runtime.
"""

import numpy as np
import time
import math
import matplotlib.pyplot as plt
from PIL import Image
from numba import cuda

# ── Configuration ─────────────────────────────────────────
WIDTH   = 4096
HEIGHT  = 4096
GAP     = 20
BLOCK   = 16

# ── CUDA Kernel ───────────────────────────────────────────
@cuda.jit
def nested_squares_kernel(img, width, height, gap):
    x, y = cuda.grid(2)
    if x >= width or y >= height:
        return
    cx   = x - width  // 2
    cy   = y - height // 2
    dist = max(abs(cx), abs(cy))
    img[y, x] = 255 if (dist % gap == 0) else 0


# ── CPU Reference ─────────────────────────────────────────
def nested_squares_cpu(width, height, gap):
    img = np.zeros((height, width), dtype=np.uint8)
    for y in range(height):
        for x in range(width):
            cx   = x - width  // 2
            cy   = y - height // 2
            dist = max(abs(cx), abs(cy))
            if dist % gap == 0:
                img[y, x] = 255
    return img


def main():
    print("=" * 55)
    print("  Nested Square Pattern  |  Roll: 25201328")
    print(f"  Grid: {WIDTH} x {HEIGHT}  |  Gap: {GAP} px")
    print("=" * 55)

    h_img = np.zeros((HEIGHT, WIDTH), dtype=np.uint8)
    d_img = cuda.to_device(h_img)

    threads_per_block = (BLOCK, BLOCK)
    bx = math.ceil(WIDTH  / BLOCK)
    by = math.ceil(HEIGHT / BLOCK)

    # Warm-up launch
    nested_squares_kernel[(bx, by), threads_per_block](d_img, WIDTH, HEIGHT, GAP)
    cuda.synchronize()

    # Timed GPU run
    t0 = time.perf_counter()
    nested_squares_kernel[(bx, by), threads_per_block](d_img, WIDTH, HEIGHT, GAP)
    cuda.synchronize()
    gpu_ms = (time.perf_counter() - t0) * 1000

    gpu_img = d_img.copy_to_host()
    print(f"\n[GPU] Time : {gpu_ms:.4f} ms")

    # CPU run
    t0 = time.perf_counter()
    cpu_img = nested_squares_cpu(WIDTH, HEIGHT, GAP)
    cpu_ms = (time.perf_counter() - t0) * 1000
    print(f"[CPU] Time : {cpu_ms:.4f} ms")

    match = np.array_equal(gpu_img, cpu_img)
    print(f"\n[VERIFY]   : {'PASS' if match else 'FAIL'}")
    print(f"[SPEEDUP]  : {cpu_ms / gpu_ms:.2f}x")

    Image.fromarray(gpu_img).save("gpu_nested_squares.png")
    Image.fromarray(cpu_img).save("cpu_nested_squares.png")

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    axes[0].imshow(gpu_img, cmap='gray')
    axes[0].set_title(f'GPU Output\n{gpu_ms:.2f} ms', fontweight='bold', color='green')
    axes[0].axis('off')
    axes[1].imshow(cpu_img, cmap='gray')
    axes[1].set_title(f'CPU Output\n{cpu_ms:.2f} ms', fontweight='bold', color='red')
    axes[1].axis('off')
    bars = axes[2].bar(['GPU', 'CPU'], [gpu_ms, cpu_ms], color=['#1D9E75', '#D85A30'], width=0.4)
    for bar, val in zip(bars, [gpu_ms, cpu_ms]):
        axes[2].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                     f'{val:.2f} ms', ha='center', fontweight='bold')
    axes[2].set_ylabel('Time (ms)')
    axes[2].set_title(f'Speedup: {cpu_ms/gpu_ms:.1f}x', fontweight='bold')
    axes[2].spines['top'].set_visible(False)
    axes[2].spines['right'].set_visible(False)
    plt.suptitle(f'Nested Square Pattern | {WIDTH}x{HEIGHT} | Gap={GAP}px | Roll: 25201328',
                 fontsize=13, fontweight='bold')
    plt.tight_layout()
    plt.savefig("performance_comparison.png", dpi=150, bbox_inches='tight')
    plt.show()
    print("\nDone. Images saved.")


if __name__ == "__main__":
    main()
